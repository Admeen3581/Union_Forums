//
//  ExploreView.swift
//  Union_Forums
//
//  Created by Adam Long on 4/27/22.
//

import SwiftUI

struct ExploreView: View
{
    var body: some View
    {
        Text("Useless View that I haven't removed, because theres a searchbar on the home page")
    }
}

struct ExploreView_Previews: PreviewProvider
{
    static var previews: some View
    {
        ExploreView()
    }
}
