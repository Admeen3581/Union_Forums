//
//  HomeView.swift
//  Union_Forums
//
//  Created by Adam Long on 4/21/22.
//

import SwiftUI

struct HomeView: View
{
    
    var body: some View
    {
        Text("HomeView")
    }
}

struct HomeView_Previews: PreviewProvider
{
    static var previews: some View
    {
        HomeView()
    }
}
